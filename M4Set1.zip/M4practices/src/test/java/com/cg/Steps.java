package com.cg;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Steps 
{
	WebDriver driver = null;
	PageModel model=null;
	@Given("^user is in ConferenceRegistartion page$")
	public void user_is_in_ConferenceRegistartion_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver","C:\\chromeDriver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("file:///C:/Users/bopvenka/Desktop/Set%2001/ConferenceRegistartion.html");
		model=new PageModel(driver);
		
	
	}

	@Then("^verify the title of the  ConferenceRegistartion$")
	public void verify_the_title_of_the_ConferenceRegistartion() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
		System.out.println("title on page"+driver.getTitle());
		driver.close();
	}

	@When("^no data entered in the first name textbox$")
	public void no_data_entered_in_the_first_name_textbox() throws Throwable 
	{
	   //model.getFirstName().sendKeys("");
	  
	   model.triggerClick();
	   //
	}

	@Then("^alert message First Name must be filled out$")
	public void alert_message_First_Name_must_be_filled_out() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the First Name";
		String actualMessage=driver.switchTo().alert().getText();
		
		assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}
	@When("^no data entered in the Last name textbox$")
	public void no_data_entered_in_the_Last_name_textbox() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		   model.getFirstName().sendKeys("venky");
		 model.getLastName().sendKeys("");
		   model.triggerClick();
		  // 
	}


	@Then("^alert message Last Name must be filled out$")
	public void alert_message_Last_Name_must_be_filled_out() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the Last Name";
		String actualMessage=driver.switchTo().alert().getText();
		//System.out.println(actualMessage);
		
		assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}
	@When("^user invalid email$")
	public void user_invalid_email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 model.getFirstName().sendKeys("venky");
		 model.getLastName().sendKeys("boppudi");
		 model.getEmail().sendKeys("");
		 model.triggerClick();
		 
	}

	@Then("^alert message Please fill the Email$")
	public void alert_message_Please_fill_the_Email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the Email";
		String actualMessage=driver.switchTo().alert().getText();
	      System.out.println(actualMessage);
		
		assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	   
	}
	@When("^Character data entered in the Mobile text box$")
	public void character_data_entered_in_the_Mobile_text_box() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		model.getFirstName().sendKeys("venky");
		 model.getLastName().sendKeys("boppudi");
		 model.getEmail().sendKeys("bv@gmail.com");
		 model.getMobileno().sendKeys("ghfa");
		 model.triggerClick();
		 
		
	 
	}

	@Then("^alert message Enter numeric value$")
	public void alert_message_Enter_numeric_value() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please enter valid Contact no.";
		String actualMessage=driver.switchTo().alert().getText();
	      System.out.println(actualMessage);
		
		assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^wrong data entered in the Mobile text box$")
	public void wrong_data_entered_in_the_Mobile_text_box() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		model.getFirstName().sendKeys("venky");
		 model.getLastName().sendKeys("boppudi");
		 model.getEmail().sendKeys("bv@gmail.com");
		 model.getMobileno().sendKeys("12345678912");
		 model.triggerClick();
		 
	}

	@Then("^alert message Enter (\\d+) digit Mobile number$")
	public void alert_message_Enter_digit_Mobile_number(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please enter valid Contact no.";
		String actualMessage=driver.switchTo().alert().getText();
	      System.out.println(actualMessage);
		
		assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	 
	}

	@When("^invalid people data$")
	public void invalid_people_data() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		model.getFirstName().sendKeys("venky");
		 model.getLastName().sendKeys("boppudi");
		 model.getEmail().sendKeys("bv@gmail.com");
		 model.getMobileno().sendKeys("8297161636");
		 model.getNo_people().sendKeys("");
		//
		 model.triggerClick();
		 
	   
	}

	@Then("^alert message Please fill the Number of people attending$")
	public void alert_message_Please_fill_the_Number_of_people_attending() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the Number of people attending";
		String actualMessage=driver.switchTo().alert().getText();
	      System.out.println(actualMessage);
		
		assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	    
	}

	@When("^invalid Building Name & Room No$")
	public void invalid_Building_Name_Room_No() throws Throwable
    {
	    // Write code here that turns the phrase above into concrete actions
		model.getFirstName().sendKeys("venky");
		 model.getLastName().sendKeys("boppudi");
		 model.getEmail().sendKeys("bv@gmail.com");
		 model.getMobileno().sendKeys("8297161636");
		 model.getNo_people().sendKeys("3");
		 model.getBuildingName_RoomNo().sendKeys("");
		//
		 model.triggerClick();
		 
	}
	@Then("^alert message Please fill the Building & Room No$")
	public void alert_message_Please_fill_the_Building_Room_No() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the Building & Room No";
		String actualMessage=driver.switchTo().alert().getText();
	      System.out.println(actualMessage);
		
		assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^invalid Area Name$")
	public void invalid_Area_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		model.getFirstName().sendKeys("venky");
		 model.getLastName().sendKeys("boppudi");
		 model.getEmail().sendKeys("bv@gmail.com");
		 model.getMobileno().sendKeys("8297161636");
		 model.getNo_people().sendKeys("3");
		 model.getBuildingName_RoomNo().sendKeys("2");
		// model.getAreaName().sendKeys("");
		//
		 model.triggerClick();
		 
	}

	@Then("^alert message Please fill the Area name$")
	public void alert_message_Please_fill_the_Area_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the Area name";
		String actualMessage=driver.switchTo().alert().getText();
	      System.out.println(actualMessage);
		
		assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

@When("^user enter invalid City$")
public void user_enter_invalid_City() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	model.getFirstName().sendKeys("venky");
	 model.getLastName().sendKeys("boppudi");
	 model.getEmail().sendKeys("bv@gmail.com");
	 model.getMobileno().sendKeys("8297161636");
	 model.getNo_people().sendKeys("3");
	 model.getBuildingName_RoomNo().sendKeys("2");
	 model.getAreaName().sendKeys("chennai");
	 
	//new Select(driver.findElement(By.name("city"))).selectByVisibleText("Select City");
	// new Select(driver.findElement(By.name("country"))).selectByVisibleText("(Please select a country)");
	 model.triggerClick();
	 
}

@Then("^display 'Please select city'$")
public void display_Please_select_city() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	String expectedMessage="Please select city";
	String actualMessage=driver.switchTo().alert().getText();
      System.out.println(actualMessage);
	
	assertEquals(expectedMessage, actualMessage);
	driver.switchTo().alert().accept();
	driver.close();
}
@When("^user enter invalid State$")
public void user_enter_invalid_State() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	model.getFirstName().sendKeys("venky");
	 model.getLastName().sendKeys("boppudi");
	 model.getEmail().sendKeys("bv@gmail.com");
	 model.getMobileno().sendKeys("8297161636");
	 model.getNo_people().sendKeys("3");
	 model.getBuildingName_RoomNo().sendKeys("2");
	 model.getAreaName().sendKeys("chennai");
	
	 //model.getCity().sendKeys("3");
	 new Select(driver.findElement(By.name("city"))).selectByVisibleText("Chennai");
 // model.getState().sendKeys("9");
	 model.triggerClick();
	 
}

@Then("^display 'Please fill the State'$")
public void display_Please_fill_the_State() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	String expectedMessage="Please select state";
	String actualMessage=driver.switchTo().alert().getText();
      System.out.println(actualMessage);
	
	assertEquals(expectedMessage, actualMessage);
	driver.switchTo().alert().accept();
	driver.close();
}

@When("^user enter invalid Member Status$")
public void user_enter_invalid_Member_Status() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	  // Write code here that turns the phrase above into concrete actions
		model.getFirstName().sendKeys("venky");
		 model.getLastName().sendKeys("boppudi");
		 model.getEmail().sendKeys("bv@gmail.com");
		 model.getMobileno().sendKeys("8297161636");
		 model.getNo_people().sendKeys("3");
		 model.getBuildingName_RoomNo().sendKeys("2");
		 model.getAreaName().sendKeys("chennai");
		
		 new Select(driver.findElement(By.name("city"))).selectByVisibleText("Chennai");
		 new Select(driver.findElement(By.name("state"))).selectByVisibleText("Tamilnadu");
	  model.getStatus().sendKeys("");
		 model.triggerClick();
		 
}

@Then("^display 'Please fill the Member Status'$")
public void display_Please_fill_the_Member_Status() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	String expectedMessage="Please Select MemeberShip status";
	String actualMessage=driver.switchTo().alert().getText();
      System.out.println(actualMessage);
	
	assertEquals(expectedMessage, actualMessage);
	driver.switchTo().alert().accept();
	driver.close();
}
@When("^Conference Details are validated$")
public void conference_Details_are_validated() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	model.getFirstName().sendKeys("venky");
	 model.getLastName().sendKeys("boppudi");
	 model.getEmail().sendKeys("bv@gmail.com");
	 model.getMobileno().sendKeys("8297161636");
	 model.getNo_people().sendKeys("3");
	 model.getBuildingName_RoomNo().sendKeys("2");
	 model.getAreaName().sendKeys("chennai");
	
	 new Select(driver.findElement(By.name("city"))).selectByVisibleText("Chennai");
	 new Select(driver.findElement(By.name("state"))).selectByVisibleText("Tamilnadu");
	 driver.findElement(By.name("memberStatus")).click();
 //model.getStatus().sendKeys("");
	 model.triggerClick();
	 
 
}

@Then("^display Conference Details are validated\\.$")
public void display_Conference_Details_are_validated() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	String expectedMessage="Conference Details are validated.";
	String actualMessage=driver.switchTo().alert().getText();
      System.out.println(actualMessage);
	
	assertEquals(expectedMessage, actualMessage);
	driver.switchTo().alert().accept();
	driver.close();
}

}
