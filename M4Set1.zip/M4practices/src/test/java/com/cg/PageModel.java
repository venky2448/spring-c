package com.cg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PageModel 
{
	private WebDriver driver = null;
	public PageModel(WebDriver driver) 
	{
		// TODO Auto-generated constructor stub
		super();
		this.driver = driver;
		//Register the Page Factory : Responsible to extract all web elements 
		PageFactory.initElements(driver, this);
	}
	@FindBy(name="txtFN")
	private WebElement firstName;

	@FindBy(name="txtLN")
	private WebElement lastName;
	
	@FindBy(name="Email")
	private WebElement email;
	@FindBy(name="Phone")
	private WebElement mobileno;
	@FindBy(name="size")
	private WebElement no_people;
	
	@FindBy(name="Address")
	private WebElement BuildingName_RoomNo;
	@FindBy(name="Address2")
	private WebElement areaName;
	@FindBy(name="city")
	private WebElement city;
	@FindBy(name="state")
	private WebElement state;
	@FindBy(name="memberStatus")
	private WebElement status;
	
	
	public WebElement getCity() {
		return city;
	}

	public void setCity(WebElement city) {
		this.city = city;
	}

	public WebElement getState() {
		return state;
	}

	public void setState(WebElement state) {
		this.state = state;
	}

	public WebElement getStatus() {
		return status;
	}

	public void setStatus(WebElement status) {
		this.status = status;
	}

	public WebElement getNo_people() {
		return no_people;
	}

	public void setNo_people(WebElement no_people) {
		this.no_people = no_people;
	}

	public WebElement getBuildingName_RoomNo() {
		return BuildingName_RoomNo;
	}

	public void setBuildingName_RoomNo(WebElement buildingName_RoomNo) {
		BuildingName_RoomNo = buildingName_RoomNo;
	}

	public WebElement getAreaName() {
		return areaName;
	}

	public void setAreaName(WebElement areaName) {
		this.areaName = areaName;
	}

	public WebElement getMobileno() {
		return mobileno;
	}

	public void setMobileno(WebElement mobileno) {
		this.mobileno = mobileno;
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(WebElement email) {
		this.email = email;
	}

	public WebElement getFirstName() {
		return firstName;
	}

	public void setFirstName(WebElement firstName) {
		this.firstName = firstName;
	}

	public WebElement getLastName() {
		return lastName;
	}

	public void setLastName(WebElement lastName) {
		this.lastName = lastName;
	}
	public void triggerClick() {
		System.out.println(" click next");
		driver.findElement(By.linkText("Next")).click();
		
	}
}
