package com.cg;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PaymentSteps
{
	WebDriver driver = null;
	PaymentModel model=null;
	@Given("^user is on Payment Details page$")
	public void user_is_on_Payment_Details_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.chrome.driver","C:\\chromeDriver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("file:///C:/Users/bopvenka/Desktop/Set%2001/PaymentDetails.html");
		model=new PaymentModel(driver);    
	}

	@Then("^valid page should open$")
	public void valid_page_should_open() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("page title "+driver.getTitle());
		assertEquals("Payment Details",driver.getTitle());
		
		driver.close();
	    
	}

	@When("^user enter invalid name$")
	public void user_enter_invalid_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		model.triggerClick();
		Thread.sleep(3000);
	}

	@Then("^display 'Please enter the name correctly'$")
	public void display_Please_enter_the_name_correctly() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String message=driver.switchTo().alert().getText();
		assertEquals("Please fill the Card holder name", message);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enter the invalid Debit Card Number$")
	public void user_enter_the_invalid_Debit_Card_Number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		model.getName().sendKeys("venky");
		model.triggerClick();
		Thread.sleep(3000);
		
	    
	}

	@Then("^display 'Please enter the Card Number correctly'$")
	public void display_Please_enter_the_Card_Number_correctly() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String message=driver.switchTo().alert().getText();
		assertEquals("Please fill the Debit card Number", message);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enter the invalidCVV$")
	public void user_enter_the_invalidCVV() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		model.getName().sendKeys("venky");
		model.getDbNo().sendKeys("2323565");
		model.triggerClick();
		Thread.sleep(3000);
	}

	@Then("^display 'Please fill the CVV'$")
	public void display_Please_fill_the_CVV() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String message=driver.switchTo().alert().getText();
		assertEquals("Please fill the CVV", message);
		driver.switchTo().alert().accept();
		driver.close();
	    
	}

	@When("^user enter invalid expiration month$")
	public void user_enter_invalid_expiration_month() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		model.getName().sendKeys("venky");
		model.getDbNo().sendKeys("2323565");
		model.getCVV().sendKeys("123");
		model.triggerClick();
		Thread.sleep(3000);
	}

	@Then("^display 'Please enter correct month of expiration'$")
	public void display_Please_enter_correct_month_of_expiration() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String message=driver.switchTo().alert().getText();
		assertEquals("Please fill expiration month", message);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enter invalid expiration year$")
	public void user_enter_invalid_expiration_year() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		model.getName().sendKeys("venky");
		model.getDbNo().sendKeys("2323565");
		model.getCVV().sendKeys("123");
		model.getMonth().sendKeys("jan");
		model.triggerClick();
		Thread.sleep(3000);
	}

	@Then("^display 'Please enter correct year of expiration'$")
	public void display_Please_enter_correct_year_of_expiration() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String message=driver.switchTo().alert().getText();
		assertEquals("Please fill the expiration year", message);
		driver.switchTo().alert().accept();
		driver.close();
	    
	}

	@When("^user enter valid  payment details$")
	public void user_enter_valid_payment_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		model.getName().sendKeys("venky");
		model.getDbNo().sendKeys("2323565");
		model.getCVV().sendKeys("123");
		model.getMonth().sendKeys("jan");
		model.getYear().sendKeys("2020");
		model.triggerClick();
		Thread.sleep(3000);
	    
	}

	@Then("^display 'Conference Room Booking is done successfully'$")
	public void display_Conference_Room_Booking_is_done_successfully() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String message=driver.switchTo().alert().getText();
		assertEquals("Conference Room Booking successfully done!!!", message);
		driver.switchTo().alert().accept();
		driver.close();
	    
	}

}
