package com.cg;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PaymentModel 
{
	private WebDriver driver = null;

	public PaymentModel(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(name="txtFN")
	private WebElement name;
	@FindBy(name="debit")
	private WebElement dbNo;
	@FindBy(name="cvv")
	private WebElement CVV;
	@FindBy(name="month")
	private WebElement month;
	@FindBy(name="year")
	private WebElement year;
	@FindBy(id="btnPayment")
	private WebElement button;

	public WebElement getName() {
		return name;
	}
	public void setName(WebElement name) {
		this.name = name;
	}
	public WebElement getDbNo() {
		return dbNo;
	}
	public void setDbNo(WebElement dbNo) {
		this.dbNo = dbNo;
	}
	public WebElement getCVV() {
		return CVV;
	}
	public void setCVV(WebElement cVV) {
		CVV = cVV;
	}
	public WebElement getMonth() {
		return month;
	}
	public void setMonth(WebElement month) {
		this.month = month;
	}
	public WebElement getYear() {
		return year;
	}
	public void setYear(WebElement year) {
		this.year = year;
	}
	public void triggerClick() {
		System.out.println("Button click triggered");
		button.click();
	}
}
