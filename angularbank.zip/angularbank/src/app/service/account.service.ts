import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AccountService {

  constructor(private http:HttpClient) { }
  baseUrl:string = 'http://localhost:3000/accounts';
    // Get All Account
    getAccount(){
      return this.http.get<Account[]>(this.baseUrl);
    }
  
    // Get Account By Id
    getAccountById(id: number){
      return this.http.get<Account>(this.baseUrl+'/'+id);
    }
  
    // Create Account
    createaccount(Account: Account) {
      return this.http.post(this.baseUrl, Account);
    }
  
    // Modify Account
    updateaccount(Account: Account) {
      return this.http.put(this.baseUrl + '/' + Account.id, Account);
    }
  
    // Delete Account
    delete(id: number) {
      return this.http.delete(this.baseUrl + '/' + id);
    }
  }
  

