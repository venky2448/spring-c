import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AccountService } from '../service/account.service';

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {
  withdrawForm: FormGroup;
  submitted: boolean = false;
  invalid: boolean = false;
  constructor(private formBuilder: FormBuilder, private router: Router,private accountservice:AccountService) {}
  onSubmit() {
    this.submitted = true;
    if (this.withdrawForm.invalid) {
      return;
    }
    console.log(this.withdrawForm.value);
      this.accountservice.updateaccount(this.withdrawForm.value).subscribe(data=>{
        alert(this.withdrawForm.controls.firstname.value +'money withdraw successfully')
        //alert(this.depositForm.controls.f//value+'record is added successfully')
        this.router.navigate(['home'])
      });
  }

  ngOnInit() 
  {
    this.withdrawForm=this.formBuilder.group({accountnumber:['',Validators.required],
    Amount:['',Validators.required]});
  }

}
