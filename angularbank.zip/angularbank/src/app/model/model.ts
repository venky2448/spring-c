export class Account
{
    id:number;
    firstName: string;
    lastName: string;
    mobileNo: number;
    email: string;
    address: string;
    balance:number;
}
