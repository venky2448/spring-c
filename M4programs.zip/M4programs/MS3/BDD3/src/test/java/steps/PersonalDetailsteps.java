/**
 * 
 */
package steps;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.factory.BrowseFactory;
import com.cg.page.PersonalDetailsPage;

import cucumber.api.DataTable;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 * @author hjangams
 *
 */
public class PersonalDetailsteps {
	
	WebDriver webDriver;
	PersonalDetailsPage personalDetails;
	
	@Before
	public void setUp() {
		webDriver = BrowseFactory.startBrowser("chrome","D:\\BDD\\177418_harish_set3\\src\\test\\java\\html\\PersonalDetails.html");
	}
	
		@Given("^user is in Personal Details page$")
		public void user_is_in_Personal_Details_page() throws Throwable {
			personalDetails = PageFactory.initElements(webDriver, PersonalDetailsPage.class);

		}
	

	@Then("^verify the title of the Personal Details page$")
	public void verify_the_title_of_the_Personal_Details_page() throws Throwable {
		assertEquals("Personal Details", webDriver.getTitle());

	
	}

	@When("^the user leaves first name empty$")
	public void the_user_leaves_first_name_empty() throws Throwable {
		
		 personalDetails.setFirstname(""); personalDetails.setLastname("jangam");
		  personalDetails.setContactno("9948368182");
		  personalDetails.setEmail("hari@gmail.com");
		  personalDetails.setAddressline1("Pune");
		  personalDetails.setAddressline2("Hyderabad");
		  personalDetails.setCity("Pune"); personalDetails.setState("Hyderabad");
		 
	}

	@Then("^alert message please fill the first name$")
	public void alert_message_please_fill_the_first_name() throws Throwable {
		
		 try { Alert alt = webDriver.switchTo().alert(); Thread.sleep(1000); String
		  message = alt.getText(); assertEquals("Please fill the First Name", message);
		  if (message.contentEquals("Please fill the First Name")) {
		  System.out.println("The text message on alert box is " + message); } else {
		  System.out.println("the text message on alert is not correct"); }
		 alt.accept(); } catch (Exception e) {
		 System.out.println("First name is Empty"); }
		 
	}

	@When("^the user leaves last name empty$")
	public void the_user_leaves_last_name_empty() throws Throwable {
		
		  personalDetails.setFirstname("harish"); personalDetails.setLastname("");
		  personalDetails.setContactno("9948368182");
		  personalDetails.setEmail("hari@gmail.com");
		  personalDetails.setAddressline1("Pune");
		  personalDetails.setAddressline2("Hyderabad");
		  personalDetails.setCity("Pune"); personalDetails.setState("Hyderabad");
		 
	}

	@Then("^alert message please fill the last name$")
	public void alert_message_please_fill_the_last_name() throws Throwable {
		
		  try { Alert alt = webDriver.switchTo().alert(); Thread.sleep(1000); String
		  message = alt.getText(); assertEquals("Please fill the Last Name", message);
		  if (message.contentEquals("Please fill the Last Name")) {
		  System.out.println("The text message on alert box is " + message); } else {
		  System.out.println("the text message on alert is not correct"); }
		  alt.accept(); } catch (Exception e) {
		  System.out.println("Last name is Empty"); }
		 

	   
	}

	@When("^the user leaves email empty$")
	public void the_user_leaves_email_empty() throws Throwable {
		
		  personalDetails.setFirstname("harish");
		  personalDetails.setLastname("jangam");
		  personalDetails.setContactno("9948368182"); personalDetails.setEmail("");
		  personalDetails.setAddressline1("Pune");
		  personalDetails.setAddressline2("Hyderabad");
		  personalDetails.setCity("Pune"); personalDetails.setState("Hyderabad");
		 
	   
	}

	@Then("^alert message please fill the email$")
	public void alert_message_please_fill_the_email() throws Throwable {
		
		  try { Alert alt = webDriver.switchTo().alert(); Thread.sleep(1000); String
		  message = alt.getText(); assertEquals("Please fill the Email", message); if
		  (message.contentEquals("Please fill the Email")) {
		  System.out.println("The text message on alert box is " + message); } else {
		  System.out.println("the text message on alert is not correct"); }
		  alt.accept(); } catch (Exception e) { System.out.println("email is Empty"); }
		 
	   
	}

	@When("^the user enter incorrect email$")
	public void the_user_enter_incorrect_email() throws Throwable {
		
		  personalDetails.setFirstname("harish");
		  personalDetails.setLastname("jangam");
		  personalDetails.setContactno("9948368182");
		  personalDetails.setEmail("jangamsetty");
		  personalDetails.setAddressline1("Pune");
		  personalDetails.setAddressline2("Hyderabad");
		  personalDetails.setCity("Pune"); personalDetails.setState("Hyderabad");
		 
	 
	}

	@Then("^alert message please fill valid email$")
	public void alert_message_please_fill_valid_email() throws Throwable {
		
		  try { Alert alt = webDriver.switchTo().alert(); Thread.sleep(1000); String
		  message = alt.getText(); assertEquals("Please enter valid Email Id.",
		  message); alt.accept(); } catch (Exception e) {
		  System.out.println("email is Empty"); }
		
	  
	}

	@When("^the user leaves contact no empty$")
	public void the_user_leaves_contact_no_empty() throws Throwable {
		
		  personalDetails.setFirstname("harish");
		  personalDetails.setLastname("jangam"); personalDetails.setContactno("");
		  personalDetails.setEmail("hari@gmail.com");
		  personalDetails.setAddressline1("Pune");
		  personalDetails.setAddressline2("Hyderabad");
		  personalDetails.setCity("Pune"); personalDetails.setState("Hyderabad");
		 
	  
	}

	@When("^clicks Confirm next button$")
	public void clicks_Confirm_next_button() throws Throwable {
		
	   
	}

	@Then("^alert message please fill the numberr Alert message$")
	public void alert_message_please_fill_the_numberr_Alert_message() throws Throwable {
		
		  try { Alert alt = webDriver.switchTo().alert(); Thread.sleep(1000); String
		  message = alt.getText(); assertEquals("Please fill the contact No.",
		  message); if (message.contentEquals("Please fill the Mobile No.")) {
		  System.out.println("The text message on alert box is " + message); } else {
		  System.out.println("the text message on alert is not correct"); }
		  alt.accept(); } catch (Exception e) {
		  System.out.println("contact no is Empty"); }
		 
	   
	}

	@When("^user enters the incorrect Contact Number format$")
	public void user_enters_the_incorrect_Contact_Number_format(DataTable arg1) throws Throwable {
		
		  personalDetails.setFirstname("harish");
		  personalDetails.setLastname("jangam"); personalDetails.setContactno("56");
		  personalDetails.setEmail("hari@gmail.com");
		  personalDetails.setAddressline1("pPune");
		  personalDetails.setAddressline2("Hyderabad");
		  personalDetails.setCity("Pune"); personalDetails.setState("Hyderabad");
		 
	}

	@Then("^alert message please enter valid contact no$")
	public void alert_message_please_enter_valid_contact_no() throws Throwable {
		
		  try { Alert alt = webDriver.switchTo().alert(); Thread.sleep(1000); String
		  message = alt.getText(); assertEquals("Please enter valid Contact no.",
		  message); if (message.contentEquals("Please enter valid Contact no.")) {
		  System.out.println("The text message on alert box is " + message); } else {
		  System.out.println("the text message on alert is not correct"); }
		  alt.accept(); } catch (Exception e) {
		  System.out.println("contact no is invalid"); }
		 

	   
	}

	@When("^the user leaves addressline(\\d+) empty$")
	public void the_user_leaves_addressline_empty(int arg1) throws Throwable {
		
		  personalDetails.setFirstname("harish");
		  personalDetails.setLastname("jangam");
		  personalDetails.setContactno("9948368285");
		  personalDetails.setEmail("hari@gmail.com");
		  personalDetails.setAddressline1("");
		  personalDetails.setAddressline2("Hyderabad");
		  personalDetails.setCity("Pune"); personalDetails.setState("Hyderabad");
		 
		 
	   
	}

	@Then("^alert message please fill the addressline(\\d+)$")
	public void alert_message_please_fill_the_addressline(int arg1) throws Throwable {
		
		  try { Alert alt = webDriver.switchTo().alert(); Thread.sleep(1000); String
		  message = alt.getText(); assertEquals("Please fill the address.", message);
		  if (message.contentEquals("Please fill the address.")) {
		  System.out.println("The text message on alert box is " + message); } else {
		  System.out.println("the text message on alert is not correct"); }
		  alt.accept(); } catch (Exception e) { System.out.println("address is Empty");
		 }
		 
	}

	@When("^the user leaves city empty$")
	public void the_user_leaves_city_empty() throws Throwable {
		
		  personalDetails.setFirstname("harish");
		  personalDetails.setLastname("jangam");
		  personalDetails.setContactno("9948368285");
		  personalDetails.setEmail("hari@gmail.com");
		  personalDetails.setAddressline1("Pune");
		  personalDetails.setAddressline2("Hyderabad"); personalDetails.setCity("");
		  personalDetails.setState("Hyderabad");
		 
	   
	}

	@Then("^alert message please fill the city$")
	public void alert_message_please_fill_the_city() throws Throwable {
		
		  try { Alert alt = webDriver.switchTo().alert(); Thread.sleep(1000); String
		  message = alt.getText(); assertEquals("Please select city", message); if
		  (message.contentEquals("Please select city")) {
		  System.out.println("The text message on alert box is " + message); } else {
		  System.out.println("the text message on alert is not correct"); }
		  alt.accept(); } catch (Exception e) { System.out.println("city is empty"); }
		 
	}

	@When("^the user leaves state empty$")
	public void the_user_leaves_state_empty() throws Throwable {
		
		 personalDetails.setFirstname("harish");
		  personalDetails.setLastname("jangam");
		  personalDetails.setContactno("9948368285");
		  personalDetails.setEmail("hari@gmail.com");
		  personalDetails.setAddressline1("Pune");
		  personalDetails.setAddressline2("Hyderabad");
		  personalDetails.setCity("Pune"); personalDetails.setState("");
		 
	   
	}

	@Then("^alert message please fill the state$")
	public void alert_message_please_fill_the_state() throws Throwable {
	
		 try { Alert alt = webDriver.switchTo().alert(); Thread.sleep(1000); String
		  message = alt.getText(); assertEquals("Please select state", message); if
		 (message.contentEquals("Please select state")) {
		  System.out.println("The text message on alert box is " + message); } else {
		  System.out.println("the text message on alert is not correct"); }
		  alt.accept(); } catch (Exception e) { System.out.println("state is empty"); }
		 

	  
	}

	@When("^the user enter valid  details$")
	public void the_user_enter_valid_details() throws Throwable {
		System.out.println("successful...");
		webDriver.navigate().to("file:D:\\BDD\\177418_harish_set3\\src\\test\\java\\html\\Validation.js");

	    	}

	@Then("^navigate to educationaldetails$")
	public void navigate_to_educationaldetails() throws Throwable {
		assertEquals("D:\\BDD\\177418_harish_set3\\src\\test\\java\\html\\EducationalDetails.html",webDriver.getCurrentUrl());

	   
	}

	@After
	public void tearDown() {
		webDriver.close();
	}



}
