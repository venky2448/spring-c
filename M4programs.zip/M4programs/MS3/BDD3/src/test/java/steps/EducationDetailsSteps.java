/**
 * 
 */
package steps;

import org.openqa.selenium.WebDriver;

import com.cg.factory.BrowseFactory;
import com.cg.page.EducationDetailsPage;
import com.cg.page.PersonalDetailsPage;


import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 * @author hjangams
 *
 */
public class EducationDetailsSteps {

	WebDriver webDriver;
	EducationDetailsPage educationDetails;
	
	@Before
	public void setUp() {
		webDriver = BrowseFactory.startBrowser("chrome","D:\\BDD\\177418_harish_set3\\src\\test\\java\\html\\EducationalDetails.html");
	}
	
	

@Given("^user is in educationdetails page$")
public void user_is_in_educationdetails_page() throws Throwable {
}

@Then("^verify the title of the page$")
public void verify_the_title_of_the_page() throws Throwable {
}

@When("^user doesnt select graduation and clicks register$")
public void user_doesnt_select_graduation_and_clicks_register() throws Throwable {
}

@Then("^alert message displays saying please select graduation$")
public void alert_message_displays_saying_please_select_graduation() throws Throwable {
}

@When("^user doesnt fill percentage$")
public void user_doesnt_fill_percentage() throws Throwable {
}

@Then("^alert message displays saying please select percentage$")
public void alert_message_displays_saying_please_select_percentage() throws Throwable {
}

@When("^user doesnt fill passing year$")
public void user_doesnt_fill_passing_year() throws Throwable {
}

@Then("^alert message displays saying please fill passing year$")
public void alert_message_displays_saying_please_fill_passing_year() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
}

@When("^user doesnt fill projectname$")
public void user_doesnt_fill_projectname() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
}

@Then("^alert message displays saying please fill projectname$")
public void alert_message_displays_saying_please_fill_projectname() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
}

@When("^user doesnt fill other technology$")
public void user_doesnt_fill_other_technology() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
}

@Then("^alert message displays saying please fill other technology$")
public void alert_message_displays_saying_please_fill_other_technology() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
}

@When("^user doesnt fill all valid details$")
public void user_doesnt_fill_all_valid_details() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
}

@Then("^alert message displays saying please saying registration successfull$")
public void alert_message_displays_saying_please_saying_registration_successfull() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
}


}
