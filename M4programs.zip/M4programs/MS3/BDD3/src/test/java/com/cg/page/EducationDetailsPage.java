/**
 * 
 */
package com.cg.page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

/**
 * @author hjangams
 *
 */
public class EducationDetailsPage {
	private WebDriver driver;
	
	@FindBy(how = How.NAME,using = "graduation")
	@CacheLookup
	private WebElement graduation;
	

	@FindBy(how = How.ID,using = "txtPercentage")
	@CacheLookup
	private WebElement txtPercentage ;
	
	@FindBy(how = How.NAME,using = "passingYear")
	@CacheLookup
	private WebElement passingYear;
	
	@FindBy(how = How.ID,using = "txtProjectName")
	@CacheLookup
	private WebElement txtProjectName ;
	
	@FindBy(how = How.ID,using = "cbTechnologies")
	@CacheLookup
	private WebElement cbTechnologies ;
	
	@FindBy(how = How.ID,using = "btnRegister")
	@CacheLookup
	private WebElement btnRegister ;

	public EducationDetailsPage() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EducationDetailsPage(WebDriver driver) {
		super();
		this.driver = driver;
	}

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getGraduation() {
		return graduation;
	}

	public void setGraduation(String graduation) {
		this.graduation.sendKeys(graduation);
	}

	public WebElement getTxtPercentage() {
		return txtPercentage;
	}

	public void setTxtPercentage(String txtPercentage) {
		this.txtPercentage.sendKeys(txtPercentage);
	}

	public WebElement getPassingYear() {
		return passingYear;
	}

	public void setPassingYear(String passingYear) {
		this.passingYear.sendKeys(passingYear);
	}

	public WebElement getTxtProjectName() {
		return txtProjectName;
	}

	public void setTxtProjectName(String txtProjectName) {
		this.txtProjectName.sendKeys(txtProjectName);
	}

	public WebElement getCbTechnologies() {
		return cbTechnologies;
	}

	public void setCbTechnologies(String cbTechnologies) {
		this.cbTechnologies.sendKeys(cbTechnologies);
	}

	public WebElement getBtnRegister() {
		return btnRegister;
	}

	public void setBtnRegister(String btnRegister) {
		this.btnRegister.sendKeys(btnRegister);
	}
	
	
	
	
	
	
	
	


}
