/**
 * 
 */
package com.cg.page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

/**
 * @author hjangams
 *
 */
public class PersonalDetailsPage {
	
	private WebDriver driver;
	
	@FindBy(how = How.ID,using = "txtFirstName")
	@CacheLookup
	private WebElement Firstname;
	

	@FindBy(how = How.ID,using = "txtLastName")
	@CacheLookup
	private WebElement Lastname;
	

	@FindBy(how = How.ID,using = "txtEmail")
	@CacheLookup
	private WebElement Email;
	

	@FindBy(how = How.ID,using = "txtPhone")
	@CacheLookup
	private WebElement Contactno;
	

	@FindBy(how = How.ID,using = "txtAddress1")
	@CacheLookup
	private WebElement Addressline1;
	
	@FindBy(how = How.ID,using = "txtAddress2")
	@CacheLookup
	private WebElement Addressline2;
	
	@FindBy(how = How.ID,using = "/html/body/form/table/tbody/tr[9]/td[2]/select")
	@CacheLookup
	private WebElement City;
	
	
	@FindBy(how = How.XPATH,using = "/html/body/form/table/tbody/tr[10]/td[2]/select")
	@CacheLookup
	private WebElement State;
	 
	private WebElement Nextbtn;

	public PersonalDetailsPage() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PersonalDetailsPage(WebDriver driver) {
		super();
		this.driver = driver;
	}

	public WebElement getFirstname() {
		return Firstname;
	}

	public void setFirstname(String firstname) {
		this.Firstname.sendKeys(firstname);
	}

	public WebElement getLastname() {
		return Lastname;
	}

	public void setLastname(String lastname) {
		this.Lastname.sendKeys(lastname);
	}

	public WebElement getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		this.Email.sendKeys(email);
	}

	public WebElement getContactno() {
		return Contactno;
	}

	public void setContactno(String contactno) {
		this.Contactno.sendKeys(contactno);
	}

	public WebElement getAddressline1() {
		return Addressline1;
	}

	public void setAddressline1(String addressline1) {
		this.Addressline1.sendKeys(addressline1);;
	}

	public WebElement getAddressline2() {
		return Addressline2;
	}

	public void setAddressline2(String addressline2) {
		this.Addressline2.sendKeys(addressline2);;
	}

	public WebElement getCity() {
		return City;
	}

	public void setCity(String city) {
		this.City.sendKeys(city); ;
	}

	public WebElement getState() {
		return State;
	}

	public void setState(String state) {
		this.State.sendKeys(state); ;
	}

	public void NextbtnClick() {
		 Nextbtn.click();
	}

	
	
	



}
