package com.cg.test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPageModel {
private WebDriver driver=null;
public LoginPageModel(WebDriver driver) 
{
	super();
	this.driver=driver;
	PageFactory.initElements(driver,this);
}
@FindBy(name="userName")
private WebElement userName;
@FindBy(name="userPwd")
private WebElement password;
@FindBy(id="userErrMsg")
private WebElement userError;
@FindBy(name="userPwdErr")
private WebElement passwordError;
@FindBy(name="btn1")
private WebElement button;
public WebElement getUserName() {
	return userName;
}
public void setUserName(WebElement userName) {
	this.userName = userName;
}
public WebElement getPassword() {
	return password;
}
public void setPassword(WebElement password) {
	this.password = password;
}
public WebElement getUserError() {
	return userError;
}
public void setUserError(WebElement userError) {
	this.userError = userError;
}
public WebElement getPasswordError() {
	return passwordError;
}
public void setPasswordError(WebElement passwordError) {
	this.passwordError = passwordError;
}

}
