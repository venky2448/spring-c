package steps;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.factory.BrowseFactory;
import com.cg.page.CoachingPage;

import cucumber.api.DataTable;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EnquiryStep {
	private WebDriver Driver;
	CoachingPage coachingPage;
	
	@Before
	public void setUp() {
		Driver=BrowseFactory.startBrowser("chrome","D:\\BDD\\177637_balaji\\src\\test\\java\\HTML\\Coaching_Class_Enquiry.html");
	}
	public void teardown() {
		Driver.close();
	}
	
	
	@Given("^user is in coaching class enquiry page$")
	public void user_is_in_coaching_class_enquiry_page() throws Throwable {
		coachingPage=PageFactory.initElements(Driver, CoachingPage.class);
	   
	}

	@Then("^verify the title of the coaching class enquiry page$")
	public void verify_the_title_of_the_coaching_class_enquiry_page() throws Throwable {
		assertEquals("online Coaching Class Enquiry form", Driver.getTitle());
		if(Driver.getTitle().equals("online Coaching Class Enquiry form")) {
			System.out.println("Title is matched");
		}else {
			System.out.println("Title is not matched");
		}
	   
	}

	@Then("^verify the text of the coaching class enquiry page$")
	public void verify_the_text_of_the_coaching_class_enquiry_page() throws Throwable {
		assertEquals("Tution Enquiry Details Form", Driver.getTitle());
		if(Driver.getTitle().equals("Tution Enquiry Details Form")) {
			System.out.println("Text is matched");
		}else {
			System.out.println("Text is not matched");
		}
	   
	}

	@When("^no data entered in the first name textbox$")
	public void no_data_entered_in_the_first_name_textbox() throws Throwable {
		coachingPage.setFirstName("");
		coachingPage.SubmitBtn();
	}

	@Then("^alert message First Name must be filled out$")
	public void alert_message_First_Name_must_be_filled_out() throws Throwable {
		Alert alt=Driver.switchTo().alert();
		Thread.sleep(1000);
		String msg=alt.getText();
		assertEquals("First Name must be filled out", msg);
		if(msg.equals("First Name must be filled out")) {
			System.out.println("the text msg on alert box is "+msg);
		}else {
			System.out.println("the text msg on alert box is not correct");
		}
	   alt.accept();
	}

	@Then("^alert message Last Name must be filled out$")
	public void alert_message_Last_Name_must_be_filled_out() throws Throwable {
		coachingPage.setLastName("");
		coachingPage.SubmitBtn();
	   
	}

	@When("^user enter email$")
	public void user_enter_email() throws Throwable {
		coachingPage.setEmail("");
		coachingPage.SubmitBtn();
		
	 
	}

	@Then("^email is entered$")
	public void email_is_entered() throws Throwable {
		Alert alt=Driver.switchTo().alert();
		Thread.sleep(1000);
		String msg=alt.getText();
		assertEquals("email must be filled out", msg);
		if(msg.equals("email must be filled out")) {
			System.out.println("the text msg on alert box is "+msg);
		}else {
			System.out.println("the text msg on alert box is not correct");
		}
	   alt.accept();
	  
	}

	@When("^Character data entered in the Mobile text box$")
	public void character_data_entered_in_the_Mobile_text_box() throws Throwable {
	  coachingPage.setMobile("samsung");
	  coachingPage.SubmitBtn();
	}

	@Then("^alert message Enter numeric value$")
	public void alert_message_Enter_numeric_value() throws Throwable {
		Alert alt=Driver.switchTo().alert();
		Thread.sleep(1000);
		String msg=alt.getText();
		assertEquals("Enter numeric value", msg);
		if(msg.equals("Enter numeric value")) {
			System.out.println("the text msg on alert box is "+msg);
		}else {
			System.out.println("the text msg on alert box is not correct");
		}
	   alt.accept();
	   
	}

	@When("^wrong data entered in the Mobile text box$")
	public void wrong_data_entered_in_the_Mobile_text_box() throws Throwable {
	  coachingPage.setMobile("123456789");
	}

	@Then("^alert message Enter (\\d+) digit Mobile number$")
	public void alert_message_Enter_digit_Mobile_number(int arg1) throws Throwable {
		try {
			Alert alt=Driver.switchTo().alert();
			Thread.sleep(1000);
			String msg=alt.getText();
			assertEquals("Enter 10 digit mobile number", msg);
			if(msg.equals("Enter 10 digit mobile number")) {
				System.out.println("the text msg on alert box is "+msg);
			}else {
				System.out.println("the text msg on alert box is not correct");
			}
   alt.accept();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	   
	}

	@When("^I enter tutiontype$")
	public void i_enter_tutiontype(DataTable arg1) throws Throwable {
	  coachingPage.setTypeOfTutionRequired("Spoken English");
	  coachingPage.SubmitBtn();
	}

	@Then("^tution type selected as Spoken English$")
	public void tution_type_selected_as_Spoken_English() throws Throwable {
		System.out.println("selected succesfully");
	   
	}

	@When("^I enter details to city$")
	public void i_enter_details_to_city(DataTable arg1) throws Throwable {
		coachingPage.setCityPreference("pune");
		coachingPage.SubmitBtn();
	   
	}

	@Then("^city preferences as Pune$")
	public void city_preferences_as_Pune() throws Throwable {
		System.out.println("selected successfully");
	   
	}

	@When("^I enter details to mode$")
	public void i_enter_details_to_mode(DataTable arg1) throws Throwable {
		coachingPage.setModeOfLearning("spoken english");
		coachingPage.SubmitBtn();
	    
	}

	@Then("^mode of learning selected as Class room training$")
	public void mode_of_learning_selected_as_Class_room_training() throws Throwable {
	   System.out.println("selected succesfully");
	}

	@When("^user click on Submit your Request button$")
	public void user_click_on_Submit_your_Request_button() throws Throwable {
	    coachingPage.setTypeOfTutionRequired("");
	    coachingPage.SubmitBtn();
	}

	@Then("^alert box displays message Enquiry details must be filled out$")
	public void alert_box_displays_message_Enquiry_details_must_be_filled_out() throws Throwable {
		Alert alt=Driver.switchTo().alert();
		Thread.sleep(1000);
		String msg=alt.getText();
		assertEquals("Enquiry details must be filled out", msg);
		if(msg.equals("Enquiry details must be filled out")) {
			System.out.println("the text msg on alert box is "+msg);
		}else {
			System.out.println("the text msg on alert box is not correct");
		}
	   alt.accept();
		
	   
	}

	@Then("^alert box displays message Thank you for submitting the online coachinf Class Enquiry$")
	public void alert_box_displays_message_Thank_you_for_submitting_the_online_coachinf_Class_Enquiry() throws Throwable {
		Alert alt=Driver.switchTo().alert();
		Thread.sleep(1000);
		String msg=alt.getText();
		assertEquals("Thank you for submitting", msg);
		if(msg.equals("Thank you for submitting")) {
			System.out.println("the text msg on alert box is "+msg);
		}else {
			System.out.println("the text msg on alert box is not correct");
		}
	   alt.accept();
		
	}

	@When("^user click Ok$")
	public void user_click_Ok() throws Throwable {
		System.out.println("selected succesfully");
	   
	}

	@Then("^verify text Our Councelor will contact you soon$")
	public void verify_text_Our_Councelor_will_contact_you_soon() throws Throwable {
		Alert alt=Driver.switchTo().alert();
		Thread.sleep(1000);
		String msg=alt.getText();
		assertEquals("Our Councelor will contact you soon$", msg);
		if(msg.equals("Our Councelor will contact you soon$")) {
			System.out.println("the text msg on alert box is "+msg);
		}else {
			System.out.println("the text msg on alert box is not correct");
		}
	   alt.accept();
		
	  
	}

	@Then("^close the browser window$")
	public void close_the_browser_window() throws Throwable {
		System.out.println("selected succesfully");
	  	}



}
