package com.cg.factory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class BrowseFactory {
	static WebDriver webDriver;

	public static WebDriver startBrowser(String name,String url) {
		System.out.println(name+"started");
		if(name.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver",
					"C:\\chromeDriver\\chromedriver.exe");
			webDriver=new ChromeDriver();
			}else if(name.equalsIgnoreCase("firefox")){
				System.setProperty("webdriver.firefox.driver",
						"C:\\chromeDriver\\chromedriver.exe");
				webDriver=new FirefoxDriver();	
			}else {
				System.setProperty("webdriver.ie.driver",
						"C:\\chromeDriver\\chromedriver.exe");
				webDriver=new InternetExplorerDriver();	
			}
	webDriver.get(url);
	return webDriver;

	}

		
	}


