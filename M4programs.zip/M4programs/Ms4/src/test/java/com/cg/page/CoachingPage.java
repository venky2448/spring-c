package com.cg.page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class CoachingPage {
	
	private WebDriver webDriver;
	@FindBy(how = How.ID,using = "fname")
	@CacheLookup
	private WebElement firstName;
	@FindBy(how = How.ID_OR_NAME,using = "lname")
	@CacheLookup
	private WebElement lastName;
	@FindBy(how = How.ID,using = "emails")
	@CacheLookup
	private WebElement email;
	@FindBy(how = How.ID,using = "mobile")
	@CacheLookup
	private WebElement mobile;
	@FindBy(how = How.NAME,using = "D6")
	@CacheLookup
	private WebElement typeOfTutionRequired;
	@FindBy(how = How.NAME,using = "D5")
	@CacheLookup
	private WebElement cityPreference;
	@FindBy(how = How.NAME,using = "D4")
	@CacheLookup
	private WebElement modeOfLearning;
	@FindBy(how= How.XPATH,using = "//*[@id=\"enqdetails\"]")
	@CacheLookup
	private WebElement enquiry;
	@FindBy(how = How.CLASS_NAME,using = "auto_style7")
	@CacheLookup
	private WebElement text;
	@FindBy(how = How.CLASS_NAME,using = "auto_style1")
	@CacheLookup
	private WebElement submitBtn;
	public CoachingPage() {
		super();
		
	}
	public CoachingPage(WebDriver webDriver) {
		super();
		this.webDriver = webDriver;
	}
	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}
	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}
	public void setEmail(String email) {
		this.email.sendKeys(email);
	}
	public void setMobile(String mobile) {
		this.mobile.sendKeys(mobile);
	}
	public void setTypeOfTutionRequired(String typeOfTutionRequired) {
		this.typeOfTutionRequired.sendKeys(typeOfTutionRequired);
	}
	public void setCityPreference(String cityPreference) {
		this.cityPreference.sendKeys(cityPreference);
	}
	public void setModeOfLearning(String modeOfLearning) {
		this.modeOfLearning.sendKeys(modeOfLearning);
	}
	public void setEnquiry(WebElement enquiry) {
		this.enquiry = enquiry;
	}
	
	public WebElement getText() {
		return text;
		
	}
	public void SubmitBtn() {
		this.submitBtn.click();
	}

}
