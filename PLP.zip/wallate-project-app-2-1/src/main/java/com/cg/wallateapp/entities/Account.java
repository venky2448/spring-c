package com.cg.wallateapp.entities;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@Entity
@Table(name="walletaccount")
public class Account {
	private Integer accountNumber;
	private String custerName;
	@Id
	private Integer mobileNo;
	private Double balance;
	public Account() {
		// TODO Auto-generated constructor stub
	}
	
	public Account(Integer accountNumber, String custerName, Integer mobileNo, Double balance) {
		super();
		this.accountNumber = accountNumber;
		this.custerName = custerName;
		this.mobileNo = mobileNo;
		this.balance = balance;
	}

	public Integer getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(Integer accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getCusterName() {
		return custerName;
	}
	public void setCusterName(String custerName) {
		this.custerName = custerName;
	}
	public Integer getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(Integer mobileNo) {
		this.mobileNo = mobileNo;
	}
	public Double getBalance() {
		return balance;
	}
	public void setBalance(Double balance) {
		this.balance = balance;
	}
	
}
