package com.cg.wallateapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.wallateapp.dao.AccountDao;
import com.cg.wallateapp.entities.Account;
import com.cg.wallateapp.exception.WalletException;
@Service
public class AccountServiceImpl implements AccountService {
@Autowired private AccountDao dao;
	@Override
	public void createAccount(Account ac) {
		// TODO Auto-generated method stub
		 dao.save(ac);
	}

	
	@Override
	public void delete(Integer mobileNumber) throws WalletException {
		// TODO Auto-generated method stub
		dao.deleteById(mobileNumber);
	}

	@Override
	public Account getAccountBymobile(Integer mobileNo) throws WalletException {
		// TODO Auto-generated method stub
		return dao.findById(mobileNo).get();
	}
	/*@Override
	public Account updateAccount(Account ac) throws WalletException {
		// TODO Auto-generated method stub
		return dao.updateAccount(ac);
	}
*/

	@Override
	public void add(double amount, Integer mobileno) {
		// TODO Auto-generated method stub
		Account a=getAccountBymobile(mobileno);
		if(a!=null) {
			double bal=a.getBalance()+amount;
			a.setBalance(bal);
			dao.save(a);
		}
		
	}


	@Override
	public void withdraw(double amount, Integer mobilNO) {
		// TODO Auto-generated method stub
		Account a=getAccountBymobile(mobilNO);
		if(a!=null) {
			double bal=a.getBalance()-amount;
			a.setBalance(bal);
			dao.save(a);
		}
		
	}


	@Override
	public void transferMoney(Integer mob1, Integer mob2,Double amount) 
	{
		// TODO Auto-generated method stub
		Account a=getAccountBymobile(mob1);
		if(a!=null)
		{
			double bal=a.getBalance()-amount;
			a.setBalance(bal);
			dao.save(a);
			
		}
		Account a1=getAccountBymobile(mob2);
		if(a!=null&a1!=null) 
		{
			double bal=a1.getBalance()+amount;
			a1.setBalance(bal);
			dao.save(a1);
		
	}}


	@Override
	public List<Account> getAllAccounts() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

	

}
