package com.cg.employee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.empapp.Exception.EmployeeException;
import com.cg.employee.bean.Employee;
import com.cg.employee.dao.EmployeeDao;

@Service
public class EmployeeServiceImpl implements IEmployeeService {
@Autowired private EmployeeDao empdao;
	@Override
	public void createEmployee(Employee emp) 
	{
		// TODO Auto-generated method stub
		empdao.save(emp);

	}

	@Override
	public Employee findByEmployeeId(String empid)throws EmployeeException {
		// TODO Auto-generated method stub
		Employee emp=empdao.findById(empid).get();
		if(emp!=null)
			return emp;
			else
				throw new EmployeeException("Does not match with any Employee ");
		//return null;
	}

	@Override
	public void deleteEmployee(String empid)throws EmployeeException {
		// TODO Auto-generated method stub
		if(findByEmployeeId(empid)!=null)
			empdao.deleteById(empid);
		else
			throw new EmployeeException("Still Employee is exits ");

	}

	@Override
	public void updateEmployee(Employee emp)throws EmployeeException {
		// TODO Auto-generated method stub
		
			createEmployee(emp);
		
			
	}

	@Override
	public List<Employee> viewEmployeeList() {
		// TODO Auto-generated method stub
		return empdao.findAll();
	}

}
