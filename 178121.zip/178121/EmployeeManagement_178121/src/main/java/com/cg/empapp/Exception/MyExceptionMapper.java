package com.cg.empapp.Exception;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

@ControllerAdvice
public class MyExceptionMapper {
	@ExceptionHandler(value=EmployeeException.class)
@ResponseBody
protected ResponseEntity<String>handleError(EmployeeException ex,HttpServletRequest req){
		String message=ex.getMessage();
		System.out.println("Caught Exception "+message);
		String url=req.getRequestURI().toString();
		System.out.println("Error At "+url);
		return new ResponseEntity<String>(message,HttpStatus.BAD_REQUEST);
	}
}
