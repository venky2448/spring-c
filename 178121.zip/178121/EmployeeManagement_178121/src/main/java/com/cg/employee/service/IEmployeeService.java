package com.cg.employee.service;

import java.util.List;

import com.cg.employee.bean.Employee;

public interface IEmployeeService {
void createEmployee(Employee emp);
Employee findByEmployeeId(String empid);
void deleteEmployee(String empid);
void updateEmployee(Employee emp);
List<Employee>viewEmployeeList();
}
