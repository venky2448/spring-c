package com.cg.employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.employee.bean.Employee;
import com.cg.employee.service.IEmployeeService;


@RestController

public class EmployeeController 
{
	@Autowired private IEmployeeService service;
	@PostMapping(value="/createmployee")
	public ResponseEntity<String>createEmployee(@RequestBody Employee emp){
		service.createEmployee(emp);
		return  new ResponseEntity<String>("Employee Record is created",HttpStatus.CREATED);
	}
	@GetMapping(value="/employees")
	public List<Employee>viewEmployeeList()
	{
		return service.viewEmployeeList();
	}
	@GetMapping(value="/getbyid")
	public Employee search(@RequestParam String empId) 
	{
		return service.findByEmployeeId(empId);
		
	}
	@PutMapping(value="/updateemployee")
	public ResponseEntity<String>update(@RequestBody Employee emp){
		service.updateEmployee(emp);
		return  new ResponseEntity<String>("Employee updated",HttpStatus.OK);
	}
	@DeleteMapping(value="/delete")
	public ResponseEntity<String>delete(@RequestParam String empId)
	{
		service.deleteEmployee(empId);
		return new ResponseEntity<String>("Employee Record deleted",HttpStatus.OK);
		
	}

}
